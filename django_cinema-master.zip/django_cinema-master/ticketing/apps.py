from django.apps import AppConfig


class TicketingConfig(AppConfig):
    name = 'ticketing'
    verbose_name = 'مدیریت فروش بلیت'
